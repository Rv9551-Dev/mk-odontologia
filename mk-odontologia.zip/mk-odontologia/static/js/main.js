(function () {
    const button = document.getElementById("menuButton");
    const menu = document.getElementById("menu");
    if (!button || !menu) return;

    const setMenu = (open) => {
        menu.classList.toggle("is-open", open);
        button.classList.toggle("is-open", open);
        button.setAttribute("aria-expanded", String(open));
        button.setAttribute("aria-label", open ? "Fechar menu" : "Abrir menu");
        document.body.classList.toggle("menu-open", open);
    };

    button.addEventListener("click", () => setMenu(!menu.classList.contains("is-open")));
    menu.querySelectorAll("a").forEach((link) => link.addEventListener("click", () => setMenu(false)));
    document.addEventListener("keydown", (event) => {
        if (event.key === "Escape" && menu.classList.contains("is-open")) {
            setMenu(false);
            button.focus();
        }
    });
    window.addEventListener("resize", () => {
        if (window.innerWidth > 820) setMenu(false);
    });
}());