# MK Odontologia

Site institucional da MK Odontologia, clínica odontológica em Deodápolis — MS.
O projeto usa Flask, templates Jinja, CSS e JavaScript vanilla, mantendo as
fotografias reais da clínica em `static/images/`.

## Run

The Replit workflow runs:

```sh
gunicorn --bind 0.0.0.0:5000 app:app
```

For direct development startup, `python app.py` also binds to the port in
`PORT` (5000 by default).

## Environment

- `SESSION_SECRET` configura a chave de sessão do Flask.
- `SITE_URL` é opcional e define a URL canônica usada no sitemap e nos metadados SEO.

O formulário não envia e-mails sem um serviço externo configurado. Depois da
validação, ele orienta o visitante a continuar o contato pelo WhatsApp.