import os
import secrets

from flask import Flask, flash, redirect, render_template, request, session, url_for

app = Flask(__name__)
app.secret_key = os.environ.get('SESSION_SECRET') or secrets.token_hex(32)
SITE_URL = os.environ.get('SITE_URL', '').rstrip('/')


@app.context_processor
def inject_site_data():
    if 'csrf_token' not in session:
        session['csrf_token'] = secrets.token_urlsafe(24)
    return {
        'site_url': SITE_URL,
        'whatsapp_url': (
            'https://wa.me/5567998370185?text='
            'Ol%C3%A1%21%20Gostaria%20de%20saber%20mais%20sobre%20a%20MK%20Odontologia%20'
            'e%20gostaria%20de%20agendar%20uma%20avalia%C3%A7%C3%A3o.'
        ),
        'csrf_token': session['csrf_token'],
    }


@app.after_request
def add_security_headers(response):
    response.headers.setdefault('X-Content-Type-Options', 'nosniff')
    response.headers.setdefault('Referrer-Policy', 'strict-origin-when-cross-origin')
    response.headers.setdefault('Permissions-Policy', 'camera=(), microphone=(), geolocation=()')
    response.headers.setdefault(
        'Content-Security-Policy',
        "default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        "font-src 'self' https://fonts.gstatic.com; img-src 'self' data:; "
        "script-src 'self'; frame-ancestors 'self';"
    )
    return response

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/sobre')
def sobre():
    return render_template('sobre.html')

@app.route('/espaco')
def espaco():
    return render_template('espaco.html')

@app.route('/contato', methods=['GET', 'POST'])
def contato():
    if request.method == 'POST':
        token = request.form.get('csrf_token', '')
        if not secrets.compare_digest(token, session.get('csrf_token', '')):
            flash('Não foi possível validar o formulário. Tente novamente.', 'error')
            return redirect(url_for('contato'))

        nome = request.form.get('nome', '').strip()
        telefone = request.form.get('telefone', '').strip()
        email = request.form.get('email', '').strip()
        mensagem = request.form.get('mensagem', '').strip()
        honeypot = request.form.get('website', '').strip()

        if honeypot:
            return redirect(url_for('contato'))
        if not nome or not telefone or len(nome) > 100 or len(telefone) > 30:
            flash('Informe seu nome e WhatsApp para continuar.', 'error')
            return redirect(url_for('contato'))
        if email and ('@' not in email or len(email) > 120):
            flash('Confira o e-mail informado.', 'error')
            return redirect(url_for('contato'))
        if len(mensagem) > 1000:
            flash('A mensagem deve ter no máximo 1.000 caracteres.', 'error')
            return redirect(url_for('contato'))

        # O projeto não possui serviço de e-mail configurado. Não fingimos que
        # a mensagem foi enviada; orientamos o visitante para o WhatsApp.
        flash(
            f'Obrigado, {nome}. Para falar diretamente com a clínica, '
            'use o WhatsApp abaixo.',
            'success',
        )
        return redirect(url_for('contato'))
    return render_template('contato.html')


@app.route('/politica-de-privacidade')
def politica_privacidade():
    return render_template('politica-privacidade.html')


@app.route('/robots.txt')
def robots():
    base = SITE_URL or request.url_root.rstrip('/')
    return (
        f'User-agent: *\nAllow: /\n\nSitemap: {base}/sitemap.xml\n',
        200,
        {'Content-Type': 'text/plain; charset=utf-8'},
    )


@app.route('/sitemap.xml')
def sitemap():
    base = SITE_URL or request.url_root.rstrip('/')
    pages = ['home', 'sobre', 'espaco', 'contato', 'politica_privacidade']
    urls = '\n'.join(
        f'  <url><loc>{base}{url_for(page)}</loc></url>' for page in pages
    )
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
        f'{urls}\n</urlset>\n',
        200,
        {'Content-Type': 'application/xml; charset=utf-8'},
    )


@app.errorhandler(404)
def page_not_found(error):
    return render_template('404.html'), 404

if __name__ == '__main__':
    app.run(
        host='0.0.0.0',
        port=int(os.environ.get('PORT', 5000)),
        debug=os.environ.get('FLASK_DEBUG', '').lower() == 'true',
    )
