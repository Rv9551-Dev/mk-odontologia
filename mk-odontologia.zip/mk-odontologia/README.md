# MK Odontologia

Site institucional da MK Odontologia, consultório odontológico em Deodápolis —
Mato Grosso do Sul.

## Stack

- Python 3.12
- Flask
- Jinja
- HTML semântico, CSS e JavaScript vanilla
- Gunicorn para execução no Replit

## Desenvolvimento

```bash
pip install -r requirements.txt
python app.py
```

O site abre na porta `5000`. No Replit, o workflow usa:

```bash
gunicorn --bind 0.0.0.0:5000 app:app
```

## Configuração

Copie `.env.example` para o gerenciador de secrets/variáveis do ambiente e
defina `SESSION_SECRET`. `SITE_URL` é opcional e deve conter a URL pública sem
barra no final para canonical, Open Graph e sitemap.

## Rotas

- `/` — página institucional
- `/sobre` — apresentação da clínica
- `/espaco` — galeria da estrutura
- `/contato` — contato e formulário
- `/politica-de-privacidade` — política de privacidade
- `/robots.txt` e `/sitemap.xml` — SEO técnico